package de.unidue.inf.is.domain;

public final class fahrtexception extends RuntimeException {
	private static final long serialVersionUID = -1626236348481345515L;
		public fahrtexception(Exception e) {
	        super(e);
	    }

}
